package com.bashizip.badassview;

public class SimpleView {
}
